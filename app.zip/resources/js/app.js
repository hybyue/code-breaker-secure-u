import './bootstrap';

import { Turbo } from "@hotwired/turbo";
window.Turbo = Turbo;
