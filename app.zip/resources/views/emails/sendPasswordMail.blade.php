<!DOCTYPE html>
<html>
<head>
    <title>Your Secure-U Account Password</title>
</head>
<body>
    <h2>Hello, {{ $name }}</h2>
    <p>Your account has been created on Secure-U. Here is your password:</p>
    <p><strong>Password:</strong> {{ $password }}</p>
    <p>Please make sure to change your password after logging in for the first time.</p>
    <p>Thank you for joining Secure-U!</p>
</body>
</html>
