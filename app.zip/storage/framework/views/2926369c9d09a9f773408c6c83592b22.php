<?php $__env->startSection('title', 'Violation'); ?>
<meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">


<?php $__env->startSection('content'); ?>
<div class="container mt-3 pass-slip">

    <div class="row">
        <div class="col-md-6">
            <h4>Violation</h4>
        </div>
        <div class=" col-md-6 text-end">
            <button class="btn text-white" style="background-color: #0B9B19;" data-bs-toggle="modal" data-bs-target="#violationModal"><i class="bi bi-plus-circle-fill text-center"></i> Add New</button>
            <a href="<?php echo e(route('pdf.generate-violation', array_merge(request()->query()))); ?>" class="btn text-white" style="background-color: #0B9B19;" download="report-violation.pdf"><i class="bi bi-file-earmark-pdf-fill"></i> PDF</a>
        </div>
    </div>

    <div class="container mt-4">
        <form action="/filter_violation" method="GET">
            <div class="row pb-3">
                <div class="col-md-3">
                    <label for="start_date">Start Date:</label>
                    <input type="date" name="start_date" id="start_date" class="form-control" value="<?php echo e(request('start_date')); ?>">
                </div>
                <div class="col-md-3">
                    <label for="end_date">End Date:</label>
                    <input type="date" name="end_date" id="end_date" class="form-control" value="<?php echo e(request('end_date')); ?>">
                </div>
                <div class="col-md-1 mt-4 pt-2">
                    <button type="submit" class="btn btn-dark">Filter</button>
                </div>

                <?php if(request('start_date') || request('end_date')): ?>
                <div class="col-md-0 mt-4 pt-2">
                    <a href="/filter_violation" class="btn btn-secondary">Clear Filter</a>
                </div>
                <?php endif; ?>
            </div>
        </form>
    </div>


    <div class="container p-3 mt-4 bg-body-secondary rounded" style="overflow-x:auto;">
    <table id="violationTable" class="table table-bordered same-height-table">
        <thead>
            <tr>
                <th>Student Number</th>
                <th>Name</th>
                <th>Course</th>
                <th>Violation</th>
                <th>Date</th>
                <th>Status</th>
                <th></th>
            </tr>
        </thead>
        <tbody>

            <?php $__empty_1 = true; $__currentLoopData = $violations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $violate): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <tr  id="tr_<?php echo e($violate->id); ?>">
                <td><?php echo e($violate->student_no); ?></td>
                <td><?php echo e($violate->last_name); ?>, <?php echo e($violate->first_name); ?>

                    <?php if($violate->middle_initial): ?>
                     <?php echo e($violate->middle_initial); ?>.
                    <?php endif; ?>
                </td>
                <td><?php echo e($violate->course); ?></td>
                <td><?php echo e($violate->violation_type); ?></td>
                <td><?php echo e($violate->date); ?></td>
                <td><?php echo e($violate->violation_count); ?> violation(s)</td>
                <td>
                    <div class="d-flex justify-content-center align-items-center">
                        <div class="mx-1">
                            <a href="#" class="btn btn-sm text-white" style="background-color: #1e1f1e" data-bs-toggle="modal" data-bs-target="#viewEntries-<?php echo e($violate->id); ?>"><i class="bi bi-eye"></i></a>
                        </div>
                        <divextends class="mx-1">
                        <a href="#" class="btn btn-sm text-white" style="background-color: #063292" data-bs-toggle="modal" data-bs-target="#updateViolationModal-<?php echo e($violate->id); ?>"><i class="bi bi-pencil-square"></i></a>
                        </divextends(
                    </div>
                </td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <tr>
                <td colspan="8" class="text-center">No Data available in table</td>
            </tr>
            <?php endif; ?>
        </tbody>
    </table>
</div>

</div>

<?php echo $__env->make('sub-admin.violation.add_violation', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('sub-admin.violation.update_violation', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('sub-admin.violation.violation_js', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>



<?php $__currentLoopData = $violations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $violation): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<div class="modal fade" id="viewEntries-<?php echo e($violation->id); ?>" tabindex="-1" aria-labelledby="viewEntriesLabel-<?php echo e($violation->id); ?>" aria-hidden="true">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="viewEntriesLabel-<?php echo e($violation->id); ?>">Student Violations</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <table class="table table-bordered">
                    <thead>
                        <tr>
                            <th>Violation No.</th>
                            <th>Date</th>
                            <th>Violation Type</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $allViolations[$violation->student_no]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $entry): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($entry->violation_count); ?></td>
                            <td><?php echo e(\Carbon\Carbon::parse($entry->created_at)->format('F d, Y')); ?></td>
                            <td><?php echo e($entry->violation_type); ?></td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


<style>
    .same-height-table td {
        vertical-align: middle;
    }

</style>




<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Jenrah\Desktop\Laravel\code-breaker-secure-u\resources\views/sub-admin/violation/violation.blade.php ENDPATH**/ ?>