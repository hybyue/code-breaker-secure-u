<?php $__env->startSection('title', 'Visitors'); ?>
<meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
<?php $__env->startSection('content'); ?>
<div class="row mt-4 p-2">
    <div class="col-md-6">
        <h4>Visitor</h4>
    </div>
    <div class="col-md-6 text-end">
        <a href="javascript:void(0)" id="add-visitor-btn" class="btn text-white " style="background-color: #0B9B19" data-bs-toggle="modal" data-bs-target="#addVisitorModal">
            <i class="bi bi-plus-circle-fill"></i> Add New
        </a>
        <a href="<?php echo e(route('pdf.generate-visitor', request()->query())); ?>" class="btn text-white" style="background-color: #0B9B19;" download="report-visitors.pdf"><i class="bi bi-file-earmark-pdf-fill"></i> PDF</a>
    </div>
</div>
<div class="container mt-2">
    <form action="/filter_visitor_admin" method="GET">
        <div class="row pb-3">
            <div class="col-md-3">
                <label for="start_date"> Start Date: </label>
                <input type="date" name="start_date" id="start_date" class="form-control" required>
            </div>
            <div class="col-md-3">
                <label for="end_date"> End Date: </label>
                <input type="date" name="end_date" id="end_date" class="form-control" required>
            </div>
            <div class="col-md-1 mt-4">
                <button type="submit" class="btn btn-dark">Filter</button>
            </div>
            <?php if(request('start_date') || request('end_date')): ?>
            <div class="col-md-0 mt-4 pt-2">
                <a href="/filter_visitor_admin" class="btn btn-secondary">Clear Filter</a>
            </div>
            <?php endif; ?>
        </div>
    </form>
</div>
    
        <div class="container p-2 bg-body-secondary rounded">
        <div class="row p-4">
            <div class="col-12 p-1">
                <table id="visitorTable" class="table table-light p-3 table-bordered table-responsive table-rounded table-striped same-height-table">
                    <thead>
                        <tr>
                            <th>Date</th>
                            <th>Visitor's Name</th>
                            <th>Person to visit & Company</th>
                            <th>Purpose</th>
                            <th>Time in</th>
                            <th>Time out</th>
                            <th>Entry Count</th>
                            <th></th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__empty_1 = true; $__currentLoopData = $latestVisitors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $visit): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <tr id="tr_<?php echo e($visit->id); ?>">
                            <td><?php echo e(\Carbon\Carbon::parse($visit->date)->format('F d, Y')); ?></td>
                            <td><?php echo e($visit->last_name); ?>,  <?php echo e($visit->first_name); ?> <?php if($visit->middle_name): ?><?php echo e($visit->middle_name); ?>.<?php endif; ?> </td>
                            <td><?php echo e($visit->person_to_visit); ?></td>
                            <td><?php echo e($visit->purpose); ?></td>
                            <td><?php echo e(\Carbon\Carbon::parse($visit->time_in)->format('g:i A')); ?></td>
                            <td id="time-out-<?php echo e($visit->id); ?>" class="text-center">
                                <?php if(is_null($visit->time_out)): ?>
                                <div>
                                    <span id="time-out-display-<?php echo e($visit->id); ?>"></span>
                                    <form action="<?php echo e(route('visitor.checkout_admin', $visit->id)); ?>" method="POST">
                                        <?php echo csrf_field(); ?>
                                        <button type="submit" class="btn btn-sm text-white" style="background-color: #069206">Check</button>
                                    </form>
                                </div>
                                <?php else: ?>
                                <?php echo e(\Carbon\Carbon::parse($visit->time_out)->format('g:i A')); ?>

                                <?php endif; ?>
                            </td>
                            <td><?php echo e($visit->entry_count); ?></td>
                            <td>
                                <div class="d-flex justify-content-center align-items-center">
                                    <div class="mx-1">
                                        <a href="#" class="btn btn-sm text-white" style="background-color: #1e1f1e" data-bs-toggle="modal" data-bs-target="#viewEntries-<?php echo e($visit->id); ?>"><i class="bi bi-eye"></i></a>
                                    </div>
                                    <div class="mx-1">
                                    <a href="#" class="btn btn-sm text-white" style="background-color: #063292" data-bs-toggle="modal" data-bs-target="#updateVisitor-<?php echo e($visit->id); ?>"><i class="bi bi-pencil-square"></i></a>
                                    </div>
                                    <div class="mx-1">
                                        <a href="javascript:void(0)" onclick="deleteVisitor(<?php echo e($visit->id); ?>)" class="btn btn-sm text-white" style="background-color: #920606">
                                            <i class="bi bi-trash3-fill"></i>
                                        </a>

                                </div>
                                </div>
                            </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <tr>
                            <td colspan="8" class="text-center">No Data available in table</td>
                        </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>

    <?php echo $__env->make('admin.visitors.add_visitor', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('admin.visitors.update_visitor', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('admin.visitors.visitor_js', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


    <div id="dynamicModals">

      
      <?php $__currentLoopData = $latestVisitors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $visit): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <div class="modal fade" id="viewEntries-<?php echo e($visit->id); ?>" tabindex="-1" aria-labelledby="viewEntriesLabel-<?php echo e($visit->id); ?>" aria-hidden="true">
         <div class="modal-dialog modal-lg">
             <div class="modal-content">
                 <div class="modal-header">
                     <h5 class="modal-title" id="viewEntriesLabel-<?php echo e($visit->id); ?>">Visitor Entries</h5>
                     <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                 </div>
                 <div class="modal-body">
                     <table class="table table-bordered ">
                         <thead>
                             <tr>
                                 <th>Date</th>
                                 <th>Person to visit & Company</th>
                                 <th>Purpose</th>
                                 <th>ID Type</th>
                                 <th>Time in</th>
                                 <th>Time out</th>
                             </tr>
                         </thead>
                         <tbody>
                             <?php $__currentLoopData = $allVisitors->where('last_name', $visit->last_name)->where('first_name', $visit->first_name)->where('middle_name', $visit->middle_name)->where('date', $visit->date); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $entry): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                             <tr>
                                 <td><?php echo e(\Carbon\Carbon::parse($entry->date)->format('F d, Y')); ?></td>
                                 <td><?php echo e($entry->person_to_visit); ?></td>
                                 <td><?php echo e($entry->purpose); ?></td>
                                 <td><?php echo e($entry->id_type); ?></td>
                                 <td><?php echo e(\Carbon\Carbon::parse($entry->time_in)->format('g:i A')); ?></td>
                                 <td><?php echo e($entry->time_out ? \Carbon\Carbon::parse($entry->time_out)->format('g:i A') : 'N/A'); ?></td>
                             </tr>
                             <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                         </tbody>
                     </table>
                 </div>
             </div>
         </div>
     </div>
     <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>



<script src="<?php echo e(asset('js/visitor_admin.js')); ?>"></script>

<style>
    .same-height-table td {
        vertical-align: middle;
    }

    .error{
        color: rgb(209, 20, 20);
    }
</style>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.sidebar_admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Jenrah\Desktop\Laravel\code-breaker-secure-u\resources\views/admin/visitors/visitor_admin.blade.php ENDPATH**/ ?>