
<div id="updateDynamicModals">
<?php $__currentLoopData = $latestVisitors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $visit): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="modal fade" id="updateVisitor-<?php echo e($visit->id); ?>" tabindex="-1"
        aria-labelledby="updateVisitorModalLabel-<?php echo e($visit->id); ?>" aria-hidden="true">
        <div class="modal-dialog modal-xl">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="updateVisitorModalLabel-<?php echo e($visit->id); ?>">Edit Visitor Entries</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <form action="<?php echo e(route('visitor.update')); ?>" method="POST">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('PUT'); ?>
                        <table class="table table-bordered">
                            <thead>
                                <tr>
                                    <th>First Name</th>
                                    <th>Middle Initial</th>
                                    <th>Last Name</th>
                                    <th>Person to Visit & Company</th>
                                    <th>Purpose</th>
                                    <th>ID Type</th>
                                    <th>Entry Count</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $allVisitors->where('last_name', $visit->last_name)->where('first_name', $visit->first_name)->where('middle_name', $visit->middle_name)->where('date', $visit->date); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $entry): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <input type="hidden" name="entries[<?php echo e($entry->id); ?>][id]"
                                            value="<?php echo e($entry->id); ?>">
                                        <td>
                                            <input type="text" class="form-control"
                                                name="entries[<?php echo e($entry->id); ?>][first_name]"
                                                value="<?php echo e($entry->first_name); ?>">
                                        </td>
                                        <td>
                                            <input type="text" class="form-control"
                                                name="entries[<?php echo e($entry->id); ?>][middle_name]"
                                                value="<?php echo e($entry->middle_name); ?>">
                                        </td>
                                        <td>
                                            <input type="text" class="form-control"
                                                name="entries[<?php echo e($entry->id); ?>][last_name]"
                                                value="<?php echo e($entry->last_name); ?>">
                                        </td>
                                        <td>
                                            <input type="text" class="form-control"
                                                name="entries[<?php echo e($entry->id); ?>][person_to_visit]"
                                                value="<?php echo e($entry->person_to_visit); ?>">
                                        </td>
                                        <td>
                                            <input type="text" class="form-control"
                                                name="entries[<?php echo e($entry->id); ?>][purpose]"
                                                value="<?php echo e($entry->purpose); ?>">
                                        </td>
                                        <td>
                                            <select class="form-select" name="entries[<?php echo e($entry->id); ?>][id_type]"
                                                required>
                                                <option value="<?php echo e($entry->id_type); ?>" selected><?php echo e($entry->id_type); ?>

                                                </option>
                                                <option value="Student ID">Student ID</option>
                                                <option value="Driver License ID">Driver License ID</option>
                                                <option value="National ID">National ID</option>
                                                <option value="Employee ID">Employee ID</option>
                                                <option value="PassPort">PassPort</option>
                                                <option value="Other">Other</option>
                                            </select>
                                        </td>
                                        <td>
                                            <input class="form-control" type="number" name="entry_count" value="<?php echo e($entry->entry_count); ?>">
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                        <div class="modal-footer">
                            <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                            <button type="submit" class="btn btn-primary">Save Changes</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div><?php /**PATH C:\Users\Jenrah\Desktop\Laravel\code-breaker-secure-u\resources\views/admin/visitors/update_visitor.blade.php ENDPATH**/ ?>