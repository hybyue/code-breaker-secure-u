<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">
    <title><?php echo $__env->yieldContent('title'); ?></title>
    <link href="<?php echo e(asset('bootstrap-5.3.3-dist/css/bootstrap.css')); ?>" rel="stylesheet">

    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.3.0/font/bootstrap-icons.css">

    <style>
        .navbar-left {
            display: flex;
            align-items: center;
        }

        .navbar-logo {
            width: 40px;
            height: 40px;
            margin-right: 10px;
        }

        .navbar-title {
            font-size: 20px;
            font-weight: bold;
        }

        .drop-me {
            z-index: 1000;
        }

        .notification-button {
            display: flex;
            align-items: center;
            justify-content: center;
            width: 35px;
            height: 35px;
            border-radius: 50%;
            font-size: 0.9rem;
        }
    </style>
</head>

<body>
    <div>
        <nav class="navbar navbar-expand-lg navbar-dark" style="background-color: #A10D0D">
            <div class="container-fluid">
                <div class="navbar-left">
                    <img src="<?php echo e(URL('images/UCU-logo.png')); ?>" alt="Logo" class="navbar-logo">
                    <span class="navbar-title text-white">Urdaneta City University</span>
                </div>
                <div class="d-flex justify-content-center align-items-center">
                    <?php if(Route::has('login')): ?>
                        <?php if(auth()->guard()->check()): ?>
                            <div class="dropdown">
                                <button class="btn btn-dark notification-button position-relative" id="notificationDropdown"
                                    data-bs-toggle="dropdown" aria-expanded="false">
                                    <i class="bi bi-bell-fill"></i>
                                    <span
                                        class="position-absolute top-0 start-100 translate-middle badge rounded-pill bg-danger">
                                        <?php echo e($students->count()); ?>

                                        <span class="visually-hidden">unread messages</span>
                                    </span>
                                </button>
                                <div class="dropdown-menu notification-lists position-absolute"
                                    aria-labelledby="notificationDropdown"
                                    style="max-height: 400px; overflow-y: auto; left: -11rem;">
                                    <div class="card" style="width: 18rem;">
                                        <div class="card-header">
                                            Notifications
                                        </div>
                                        <ul class="list-unstyled">
                                           <?php $__currentLoopData = $students; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $s): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                           <li>
                                            <a class="dropdown-item" href="<?php echo e(route('admin.violation.violation')); ?>">
                                             <?php echo e($s->student_no); ?> - 3rd violation
                                                <i class="bi bi-exclamation-triangle-fill text-danger"></i>
                                            </a>
                                        </li>
                                           <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </ul>
                                    </div>
                                </div>
                            </div>
                            <div class="dropdown2">
                                <a class="btn dropdown-toggle" type="button" id="userMenuButton" data-bs-toggle="dropdown"
                                    aria-expanded="false">
                                    <img class="rounded-circle"
                                        src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSiyWg33WlX7U9e3dvdcAO0VQ3VM9RUlXJBcA&s"
                                        alt="User" width="40" height="40">
                                </a>
                                <ul class="dropdown-menu dropdown-menu-end drop-me" aria-labelledby="userMenuButton">
                                    <li><a class="dropdown-item" href="<?php echo e(route('admin.dashboard')); ?>">Home</a></li>
                                    <li><a class="dropdown-item"
                                            href="<?php echo e(route('admin.layouts.profile_admin')); ?>">Profile</a></li>
                                    <li><a class="dropdown-item" href="<?php echo e(route('auth.change-password')); ?>">Change
                                            password</a></li>
                                    <li><a class="dropdown-item" href="<?php echo e(url('/logout')); ?>">Sign out</a></li>
                                </ul>
                            </div>
                        <?php else: ?>
                            <a href="<?php echo e(route('login')); ?>" class="btn btn-outline-light">Log in</a>
                            <?php if(Route::has('register')): ?>
                                <a href="<?php echo e(route('register')); ?>" class="btn btn-outline-light ms-2">Register</a>
                            <?php endif; ?>
                        <?php endif; ?>
                    <?php endif; ?>
                </div>
            </div>
        </nav>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.3/dist/umd/popper.min.js"></script>
    <script src="<?php echo e(asset('bootstrap-5.3.3-dist/js/bootstrap.js')); ?>"></script>

</body>

</html>
<?php /**PATH C:\Users\Jenrah\Desktop\Laravel\code-breaker-secure-u\resources\views/admin/layouts/admin.blade.php ENDPATH**/ ?>