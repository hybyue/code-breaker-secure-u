<?php $__env->startSection('title', 'Dashboard'); ?>
<link rel="stylesheet" href="<?php echo e(asset('tailwindcharts/css/flowbite.min.css')); ?>">

<?php $__env->startSection('content'); ?>

<div class="container">
    <div class="row mb-4">
        <div class="col-12">
            <h4>Dashboard</h4>
        </div>
    </div>

    <div class="row mb-4">
        <div class="col-md-4 col-sm-6 mb-4">
            <div class="card-onclick card text-white" style="background-color:#2c3539;" onclick="location.href='<?php echo e(route('visitors.subadmin')); ?>'">
                <div class="card-body d-flex justify-content-between">
                    <div class="icon-container text-center d-flex justify-content-center align-items-center" >
                        <i class="bi bi-person-fill" style="font-size: 50px; color: white; vertical-align: middle;"></i>
                    </div>
                    <div class="container">
                        <h5 class="card-title">Total Visitor</h5>
                        <div class="row d-flex justify-content-between align-items-between">
                            <div class="col-md-4"> <small class="text-end">Today: <?php echo e($todayVisitors); ?></small></div>
                            <div class="col-md-4"><h4 class="text-end"><?php echo e($totalVisitors); ?></h4></div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-md-4 col-sm-6 mb-4">
            <div class="card-onclick card text-white" style="background-color:#2c3539;" onclick="location.href='#'">
                <div class="card-body d-flex justify-content-between">
                    <div class="icon-container text-center d-flex justify-content-center align-items-center" >
                        <i class="bi bi-file-earmark-person" style="font-size: 50px; color: white; vertical-align: middle;"></i>
                    </div>
                    <div class="container">
                        <h5 class="card-title">Violations</h5>
                        <h4 class="text-end"><?php echo e($totalViolation); ?></h4>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-md-4 col-sm-6 mb-4">
            <div class="card-onclick card text-white" style="background-color:#2c3539;" onclick="location.href='<?php echo e(route('sub-admin.pass_slip.pass_slip')); ?>'">
                <div class="card-body d-flex justify-content-between">
                    <div class="icon-container text-center d-flex justify-content-center align-items-center" >
                        <i class="bi bi-pass" style="font-size: 50px; color: white; vertical-align: middle;"></i>
                    </div>
                    <div class="container">
                        <h5 class="card-title">Pass Slip</h5>
                        <div class="row d-flex justify-content-between align-items-between">
                            <div class="col-md-4"><small class="text-end">Today: <?php echo e($todayPassSlips); ?></small></div>
                            <div class="col-md-4"><h4 class="text-end"><?php echo e($totalPassSlips); ?></h4></div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>



<div class="row p-3">
    <div class="col-md-6">
        <div class="container">
            <div id="timeLabel" class="text-lg font-bold mb-4"><h4>Select Time Period</h4></div>
                <div class="flex space-x-2 mb-4">
                    <button onclick="fetchData('monthly')" id="monthlyBtn" class="bg-blue-500 text-white px-4 py-2 rounded">Monthly</button>
                    <button onclick="fetchData('yearly')" id="yearlyBtn" class="bg-blue-500 text-white px-4 py-2 rounded">Yearly</button>
                </div>
                <canvas id="visitorChart" class="bg-white shadow-md rounded-lg p-4"></canvas>
        </div>
    </div>
</div>


    <div class="row mb-4">
        <div class="col-md-8">
            <div class="card">
                <div class="card-body">
                    <div id="calendar"></div>
                </div>
            </div>
        </div>
        <div class="col-md-4">
            <div class="card mb-1">
                <div class="card-body">
                    <h5>Today's Announcement(s)</h5>

                    <?php if($todayEvents->count() > 0): ?>
                    <div class="card">
                            <?php $__currentLoopData = $todayEvents; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $event): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="card-body text-start">
                                    <strong ><?php echo e($event->title); ?></strong><br>
                                    <small><strong>Date: </strong> <?php echo e($event->date_start->format('M d, Y')); ?>

                                        <?php if($event->date_end = $event->date_start): ?>

                                        <?php else: ?>
                                        to <?php echo e($event->date_end->format('M d, Y')); ?>

                                    <?php endif; ?></small>
                                    <br>
                                    <small><strong>Details:</strong> <?php echo e($event->description); ?></small><br>
                            </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                    <?php else: ?>
                    <p>No announcement today.</p>
                    <?php endif; ?>


                </div>
            </div>
            <div class="card mt-1">
                <div class="card-body">
                    <h5>Upcoming Announcement(s)</h5>
                    <?php if($upcomingEvents->count() > 0): ?>
                    <div class="card">
                            <?php $__currentLoopData = $upcomingEvents; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $event): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="card-body">
                                    <strong><?php echo e($event->title); ?></strong><br>
                                    <small><strong>Date: </strong> <?php echo e($event->date_start->format('M d, Y')); ?>

                                        <?php if($event->date_end): ?>
                                        to <?php echo e($event->date_end->format('M d, Y')); ?>

                                    <?php endif; ?></small>
                                    <br>
                                    <small><strong>Details:</strong> <?php echo e($event->description); ?></small><br>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                    </div>
                    <?php else: ?>
                        <p>No upcoming Announcement.</p>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>

<!-- FullCalendar CSS and JS -->
<link href='https://cdn.jsdelivr.net/npm/fullcalendar@5.9.0/main.min.css' rel='stylesheet' />
<script src='https://cdn.jsdelivr.net/npm/fullcalendar@5.9.0/main.min.js'></script>

<script src='<?php echo e(asset('fullcalendar/main.min.js')); ?>'></script>
<script src="<?php echo e(asset('tailwindcharts/js/apexcharts.js')); ?>"></script>
<script src="<?php echo e(asset('tailwindcharts/js/flowbite.min.js')); ?>"></script>

<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
<script>
    const ctx = document.getElementById('visitorChart').getContext('2d');
    let visitorChart;

    function fetchData(timePeriod) {
        // Update the time label
        const timeLabel = document.getElementById('timeLabel');
        timeLabel.textContent = `${capitalizeFirstLetter(timePeriod)} Statistics`;

        // Update button colors
        const buttons = document.querySelectorAll('button');
        buttons.forEach(button => {
            button.classList.remove('bg-blue-700', 'bg-blue-500');
            button.classList.add('bg-blue-500');
        });

        document.getElementById(`${timePeriod}Btn`).classList.remove('bg-blue-500');
        document.getElementById(`${timePeriod}Btn`).classList.add('bg-blue-700');

        // Fetch data based on the time period (weekly, monthly, yearly)
        fetch(`/visitor-data?timePeriod=${timePeriod}`)
            .then(response => response.json())
            .then(data => {
                updateChart(timePeriod, data.labels, data.visitor, data.passSlip, data.lost, data.violation);
            })
            .catch(error => console.error('Error fetching data:', error));
    }

    function updateChart(timePeriod, labels, visitors, pass_slips, lost_found, violations) {
        // Format labels for months if 'monthly' is selected
        if (timePeriod === 'monthly') {
            labels = labels.map(monthNum => {
                return new Date(0, monthNum - 1).toLocaleString('en-US', { month: 'long' });
            });
        }

        // Destroy the previous chart instance if it exists
        if (visitorChart) {
            visitorChart.destroy();
        }

        // Create a new chart instance
        visitorChart = new Chart(ctx, {
            type: 'bar',
            data: {
                labels: labels,
                datasets: [
                {
                    label: 'Visitor',
                    data: visitors,
                    backgroundColor: 'rgba(54, 162, 235, 0.5)',
                    borderColor: 'rgba(54, 162, 235, 1)',
                    borderWidth: 2
                },
                {
                    label: 'Pass Slips',
                    data: pass_slips,
                    backgroundColor: 'rgba(75, 192, 192, 0.5)',
                    borderColor: 'rgba(75, 192, 192, 1)',
                    borderWidth: 2
                },
                {
                    label: 'Lost and Found',
                    data: lost_found,
                    backgroundColor: 'rgba(255, 206, 86, 0.5)',
                    borderColor: 'rgba(255, 206, 86, 1)',
                    borderWidth: 2
                },
                {
                    label: 'Violations',
                    data: violations,
                    backgroundColor: 'rgba(153, 102, 255, 0.5)',
                    borderColor: 'rgba(153, 102, 255, 1)',
                    borderWidth: 2
                }
            ]
            },
            options: {
                responsive: true,
                scales: {
                    y: {
                        beginAtZero: true
                    }
                }
            }
        });
    }

    function capitalizeFirstLetter(string) {
        return string.charAt(0).toUpperCase() + string.slice(1);
    }

    // Initial load with monthly data
    fetchData('monthly');
    </script>

<style>
    .card-onclick {
        transition: transform 0.3s;
        cursor: pointer;
    }
    .card-onclick:hover {
        transform: scale(1.03);
    }

    .fc-event-container {
        background-color: #f0f0f0;
        border-radius: 5px;
    }

    .fc-event {
        background-color: #292b2e;
        color: #000000;
        border: none;
        padding: 5px;
        transition: transform 0.3s;
    }

    .fc-event:hover {
        transform: scale(1.05);
        color: #000000;
        background-color: #747474;
    }

    .event-title {
        font-weight: bold;
    }
    .icon-container{
        background-color:#cf1818;
        width: 100px;
        height: 80px;
        border-radius: 5px;
    }
    .icon-container i{
        vertical-align: middle;
    }
</style>
<script>
    document.addEventListener('DOMContentLoaded', function() {
        var calendarEl = document.getElementById('calendar');
        var calendar = new FullCalendar.Calendar(calendarEl, {
            initialView: 'dayGridMonth',
            events: [
                <?php $__currentLoopData = $events; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $event): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    {
                        title: '<?php echo e($event->title); ?>',
                        start: '<?php echo e($event->date_start->format('Y-m-d')); ?>',
                        <?php if($event->date_end): ?>
                            end: '<?php echo e($event->date_end->addDay()->format('Y-m-d')); ?>',
                        <?php endif; ?>
                    },
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            ],
            headerToolbar: {
                left: 'prev,next today',
                center: 'title',
                right: 'dayGridMonth,timeGridWeek,timeGridDay'
            }
        });
        calendar.render();
    });
</script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Jenrah\Desktop\Laravel\code-breaker-secure-u\resources\views/sub-admin/dashboard.blade.php ENDPATH**/ ?>