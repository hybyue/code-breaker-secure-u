<?php $__env->startSection('title', 'Employees'); ?>

<?php $__env->startSection('content'); ?>
<div class="container mt-3 pass-slip">

    <div class="row">
        <div class="col-md-6">
            <h4>Employees</h4>
        </div>
        <div class=" col-md-6 text-end">
            <button class="btn text-white" style="background-color: #0B9B19;" data-bs-toggle="modal" data-bs-backdrop="false" data-bs-target="#addEmployeeModalAd"><i class="bi bi-plus-circle-fill text-center"></i> Add New</button>
            <a href="<?php echo e(route('pdf.generate-lost', request()->query())); ?>" class="btn text-white" style="background-color: #0B9B19;" download="report-losts.pdf"><i class="bi bi-file-earmark-pdf-fill"></i> PDF</a>
        </div>
    </div>

    <div class="container p-3 mt-4 bg-body-secondary rounded">
    <table id="employeeTable" class="table table-bordered same-height-table">
        <thead>
            <tr>
                <th>Employee ID </th>
                <th>Name</th>
                <th>Designation</th>
                <th>Department</th>
                <th>Employee Type</th>

                <th></th>
            </tr>
        </thead>
        <tbody>
            <?php $__empty_1 = true; $__currentLoopData = $allEmployees; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $allEmployee): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <tr id="tr_<?php echo e($allEmployee->id); ?>">
            <td><?php echo e($allEmployee->employee_id); ?></td>
            <td><?php echo e($allEmployee->last_name); ?>, <?php echo e($allEmployee->first_name); ?> <?php if($allEmployee->middle_name): ?>
                <?php echo e($allEmployee->middle_name); ?>.
            <?php endif; ?></td>
            <td><?php echo e($allEmployee->designation); ?></td>
            <td><?php echo e($allEmployee->department); ?></td>
            <td><?php echo e($allEmployee->status); ?></td>

                <td>
                    <div class="d-flex justify-content-center align-items-center">
                        <div class="mx-1">
                            <a href="javascript:void(0)" class="viewModal btn btn-sm text-white" style="background-color: #1e1f1e" data-id="<?php echo e($allEmployee->id); ?>"   data-bs-toggle="modal" data-bs-target="#viewViolationAd-<?php echo e($allEmployee->id); ?>"><i class="bi bi-eye"></i></a>
                        </div>
                        <div class="mx-1">
                        <a href="javascript:void(0)" class="editModal btn btn-sm text-white" style="background-color: #063292" data-id="<?php echo e($allEmployee->id); ?>"   data-bs-toggle="modal" data-bs-target="#updateViolationModalAd-<?php echo e($allEmployee->id); ?>"><i class="bi bi-pencil-square"></i></a>
                        </div>
                        <div class="mx-1">
                            <a href="javascript:void(0)" onclick="deleteEmployee(<?php echo e($allEmployee->id); ?>)" class="btn btn-sm text-white" style="background-color: #920606">
                                <i class="bi bi-trash3-fill"></i>
                            </a>
                    </div>
                    </div>
                </td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>

        <tr>
            <td colspan="6" class="text-center">No Data available in table</td>
        </tr>
            <?php endif; ?>



        </tbody>
    </table>

</div>

</div>

<?php echo $__env->make('admin.employees.add_employee', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('admin.employees.employee_js', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>







<style>
    .same-height-table td {
        vertical-align: middle;
    }
</style>




<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.sidebar_admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Jenrah\Desktop\Laravel\code-breaker-secure-u\resources\views/admin/employees/all_employee.blade.php ENDPATH**/ ?>