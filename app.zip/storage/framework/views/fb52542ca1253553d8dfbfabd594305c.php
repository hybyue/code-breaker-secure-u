<?php $__env->startSection('title', 'Violation'); ?>
<meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">


<?php $__env->startSection('content'); ?>
<div class="container mt-3 pass-slip">

    <div class="row">
        <div class="col-md-6">
            <h4>Violation</h4>
        </div>
        <div class=" col-md-6 text-end">
            <button class="btn text-white" style="background-color: #0B9B19;" data-bs-toggle="modal" data-bs-backdrop="false" data-bs-target="#addViolationModalAd"><i class="bi bi-plus-circle-fill text-center"></i> Add New</button>
            <a href="<?php echo e(route('pdf.generate-lost', request()->query())); ?>" class="btn text-white" style="background-color: #0B9B19;" download="report-losts.pdf"><i class="bi bi-file-earmark-pdf-fill"></i> PDF</a>
        </div>
    </div>

    <div class="container p-3 mt-4 bg-body-secondary rounded">
    <table id="violationTable" class="table table-bordered same-height-table">
        <thead>
            <tr>
                <th>Student Number</th>
                <th>Name</th>
                <th>Course</th>
                <th>Violation</th>
                <th>Date</th>
                <th>Status</th>
                <th></th>
            </tr>

            <script>
                function testFunction() {
                  console.log("clicked button");
                }
            </script>
        </thead>
        <tbody>

            <?php $__empty_1 = true; $__currentLoopData = $violations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $violate): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <tr  id="tr_<?php echo e($violate->id); ?>">
                <td><?php echo e($violate->student_no); ?></td>
                <td><?php echo e($violate->last_name); ?>, <?php echo e($violate->first_name); ?>

                    <?php if($violate->middle_initial): ?>
                     <?php echo e($violate->middle_initial); ?>.
                    <?php endif; ?>
                </td>
                <td><?php echo e($violate->course); ?></td>
                <td><?php echo e($violate->violation_type); ?></td>
                <td><?php echo e($violate->date); ?></td>
                <td>
                    <?php if($violate->violation_count > 1): ?>
                    <?php echo e($violate->violation_count); ?> violations
                    <?php else: ?>
                    <?php echo e($violate->violation_count); ?> violation
                    <?php endif; ?>
                    </td>
                <td>
                    <div class="d-flex justify-content-center align-items-center">
                        <div class="mx-1">
                            <a href="javascript:void(0)" class="viewModal btn btn-sm text-white" style="background-color: #1e1f1e" data-id="<?php echo e($violate->id); ?>"   data-bs-toggle="modal" data-bs-target="#viewViolationAd-<?php echo e($violate->id); ?>"><i class="bi bi-eye"></i></a>
                        </div>
                        <div class="mx-1">
                        <a href="#" class="editModal btn btn-sm text-white" style="background-color: #063292" data-id="<?php echo e($violate->id); ?>"   data-bs-toggle="modal" data-bs-target="#updateViolationModalAd-<?php echo e($violate->id); ?>"><i class="bi bi-pencil-square"></i></a>
                        </div>
                        <div class="mx-1">
                            <a href="javascript:void(0)" onclick="deleteViolation(<?php echo e($violate->id); ?>)" class="btn btn-sm text-white" style="background-color: #920606">
                                <i class="bi bi-trash3-fill"></i>
                            </a>
                        </div>
                    </div>
                    
                </td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <tr>
                <td colspan="8" class="text-center">No Data available in table</td>
            </tr>
            <?php endif; ?>
        </tbody>
    </table>

</div>

</div>

<?php echo $__env->make('admin.violation.add_violation', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('admin.violation.update_violation', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('admin.violation.violation_js', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<div id="latestViolations">

<?php $__currentLoopData = $violations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $violation): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<div class="modal fade" id="viewViolationAd-<?php echo e($violation->id); ?>" tabindex="-1" aria-labelledby="viewViolationAdLabel-<?php echo e($violation->id); ?>" aria-hidden="true">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="viewViolationAdLabel-<?php echo e($violation->id); ?>">Student Violations</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <table class="table table-bordered">
                    <thead>
                        <tr>
                            <th>Violation No.</th>
                            <th>Date</th>
                            <th>Violation Type</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $allViolations[$violation->student_no]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $entry): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($entry->violation_count); ?></td>
                            <td><?php echo e(\Carbon\Carbon::parse($entry->created_at)->format('F d, Y')); ?></td>
                            <td><?php echo e($entry->violation_type); ?></td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>

<style>
    .same-height-table td {
        vertical-align: middle;
    }


</style>




<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.sidebar_admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Jenrah\Desktop\Laravel\code-breaker-secure-u\resources\views/admin/violation/violation.blade.php ENDPATH**/ ?>